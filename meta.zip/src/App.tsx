/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BookmarkPlus, Check, Sparkles } from 'lucide-react';
import {
  UserBodyInputs,
  HealthAnalysisResult,
  analyzeHealth,
  UnitSystem,
  StandardType,
} from './utils/healthCalculations';
import { Language, SavedScanRecord } from './types';
import { getTranslation } from './utils/translations';
import { Header } from './components/Header';
import { PresetProfiles } from './components/PresetProfiles';
import { MetricInputPanel } from './components/MetricInputPanel';
import { TriMetricHeroCards } from './components/TriMetricHeroCards';
import { PhenotypeBanner } from './components/PhenotypeBanner';
import { BodySilhouetteVisualizer } from './components/BodySilhouetteVisualizer';
import { WhatIfSimulator } from './components/WhatIfSimulator';
import { MetabolicDeepDive } from './components/MetabolicDeepDive';
import { ClinicalActionPlan } from './components/ClinicalActionPlan';
import { HistoryAndExportModal } from './components/HistoryAndExportModal';

const DEFAULT_INPUTS: UserBodyInputs = {
  gender: 'male',
  age: 30,
  unitSystem: 'metric',
  heightCm: 175,
  weightKg: 74,
  waistCm: 84,
  neckCm: 38,
  hipCm: 96,
  activityLevel: 'moderate',
  standard: 'who',
};

export default function App() {
  const [inputs, setInputs] = useState<UserBodyInputs>(DEFAULT_INPUTS);
  const [language, setLanguage] = useState<Language>('en');
  const [savedScans, setSavedScans] = useState<SavedScanRecord[]>([]);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [showSaveToast, setShowSaveToast] = useState(false);

  // Load saved scans from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('metapulse_saved_scans');
      if (stored) {
        setSavedScans(JSON.parse(stored));
      }
    } catch {
      // Ignore storage errors in restricted contexts
    }
  }, []);

  // Save to localStorage when changed
  const saveScansToStorage = (updated: SavedScanRecord[]) => {
    setSavedScans(updated);
    try {
      localStorage.setItem('metapulse_saved_scans', JSON.stringify(updated));
    } catch {
      // Ignore storage errors
    }
  };

  const results: HealthAnalysisResult = analyzeHealth(inputs);
  const t = getTranslation(language);
  const isUrdu = language === 'ur';

  const handleInputChange = (updated: Partial<UserBodyInputs>) => {
    setInputs((prev) => ({ ...prev, ...updated }));
  };

  const handleUnitSystemChange = (units: UnitSystem) => {
    setInputs((prev) => ({ ...prev, unitSystem: units }));
  };

  const handleStandardChange = (standard: StandardType) => {
    setInputs((prev) => ({ ...prev, standard }));
  };

  const handleSelectPreset = (preset: Partial<UserBodyInputs>) => {
    setInputs((prev) => ({ ...prev, ...preset }));
  };

  const handleSaveScan = () => {
    const newRecord: SavedScanRecord = {
      id: `scan-${Date.now()}`,
      timestamp: new Date().toISOString(),
      label: `Biometrics Scan (${inputs.weightKg}kg / ${inputs.waistCm}cm)`,
      inputs: { ...inputs },
      results: { ...results },
    };
    const updated = [newRecord, ...savedScans];
    saveScansToStorage(updated);
    setShowSaveToast(true);
    setTimeout(() => setShowSaveToast(false), 3000);
  };

  const handleDeleteScan = (id: string) => {
    const updated = savedScans.filter((s) => s.id !== id);
    saveScansToStorage(updated);
  };

  const handleClearHistory = () => {
    saveScansToStorage([]);
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans ${isUrdu ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <Header
        unitSystem={inputs.unitSystem}
        onUnitSystemChange={handleUnitSystemChange}
        standard={inputs.standard}
        onStandardChange={handleStandardChange}
        language={language}
        onLanguageChange={setLanguage}
        onOpenHistory={() => setIsHistoryModalOpen(true)}
        onOpenExport={() => setIsHistoryModalOpen(true)}
        savedScansCount={savedScans.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Presets Bar */}
        <PresetProfiles onSelectPreset={handleSelectPreset} language={language} />

        {/* 2-Column Primary Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Biometrics Input Controls (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <MetricInputPanel
              inputs={inputs}
              onChange={handleInputChange}
              language={language}
            />

            {/* Quick Action: Save Scan to History */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleSaveScan}
                className="w-full py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-emerald-500/60 text-xs font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md active:scale-[0.99]"
              >
                <BookmarkPlus className="w-4 h-4 text-emerald-400" />
                <span>{t.saveScan}</span>
              </button>
            </div>

            {/* Toast notification */}
            {showSaveToast && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-fade-in">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{t.saveSuccess}</span>
              </div>
            )}
          </div>

          {/* Right Column: Tri-Metric Hero Cards & Visual Models (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Tri-Metric Matrix (BMI + Body Fat % + WHtR) */}
            <TriMetricHeroCards
              results={results}
              unitSystem={inputs.unitSystem}
              language={language}
            />

            {/* Phenotype Diagnosis Banner (e.g. Skinny-Fat vs Athletic Paradox) */}
            <PhenotypeBanner results={results} language={language} />

            {/* Dynamic Body Silhouette & Visceral Fat Cross-Section */}
            <BodySilhouetteVisualizer
              inputs={inputs}
              results={results}
              language={language}
            />
          </div>
        </div>

        {/* Full-Width Section 1: Interactive What-If Metabolic Simulator */}
        <WhatIfSimulator
          currentInputs={inputs}
          currentResults={results}
          onApplyGoal={handleInputChange}
          language={language}
        />

        {/* Full-Width Section 2: Deep Dive Analytics (Tabs) */}
        <MetabolicDeepDive
          results={results}
          unitSystem={inputs.unitSystem}
          language={language}
        />

        {/* Full-Width Section 3: Personalized Clinical Action Plan */}
        <ClinicalActionPlan results={results} language={language} />

        {/* Clinical Scientific Citation Footer */}
        <div className="pt-6 border-t border-slate-900 text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            Methodology: US Navy Circumference Method (Hodgdon & Beckett), Mifflin-St Jeor Energy Equation, and Dr. Margaret Ashwell Waist-to-Height Ratio (WHtR) cardiometabolic mortality curves (UK NICE Guideline CG189/2022).
          </p>
          <div className="flex items-center gap-1.5 text-slate-400 font-semibold shrink-0">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>MetaPulse Real-Time Health Engine</span>
          </div>
        </div>
      </main>

      {/* History and Export Modal */}
      <HistoryAndExportModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        savedScans={savedScans}
        onDeleteScan={handleDeleteScan}
        onClearHistory={handleClearHistory}
        currentResults={results}
        currentUnitSystem={inputs.unitSystem}
        language={language}
      />
    </div>
  );
}
