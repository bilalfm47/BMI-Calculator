/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sliders, Sparkles, HeartHandshake, ArrowRight, CheckCircle2, RotateCcw } from 'lucide-react';
import { UserBodyInputs, HealthAnalysisResult, analyzeHealth, cmToInches, kgToLbs } from '../utils/healthCalculations';
import { Language } from '../types';
import { getTranslation } from '../utils/translations';

interface WhatIfSimulatorProps {
  currentInputs: UserBodyInputs;
  currentResults: HealthAnalysisResult;
  onApplyGoal: (simulatedInputs: Partial<UserBodyInputs>) => void;
  language: Language;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({
  currentInputs,
  currentResults,
  onApplyGoal,
  language,
}) => {
  const t = getTranslation(language);
  const isUrdu = language === 'ur';
  const isImperial = currentInputs.unitSystem === 'imperial';

  // Default suggested waist reduction based on excess
  const initialWaistDelta = currentResults.waistExcessCm > 0 ? Math.min(15, currentResults.waistExcessCm) : 3;
  const [waistDeltaCm, setWaistDeltaCm] = useState<number>(initialWaistDelta);
  const [weightDeltaKg, setWeightDeltaKg] = useState<number>(Math.round(initialWaistDelta * 0.7 * 10) / 10);

  // Compute simulated state
  const simulatedWaistCm = Math.max(45, Math.round((currentInputs.waistCm - waistDeltaCm) * 10) / 10);
  const simulatedWeightKg = Math.max(35, Math.round((currentInputs.weightKg - weightDeltaKg) * 10) / 10);

  const simulatedInputs: UserBodyInputs = {
    ...currentInputs,
    waistCm: simulatedWaistCm,
    weightKg: simulatedWeightKg,
  };

  const simulatedResults = analyzeHealth(simulatedInputs);

  // Risk reduction percentage
  const currentRisk = currentResults.cardiovascularRiskMultiplier;
  const newRisk = simulatedResults.cardiovascularRiskMultiplier;
  const riskReducedPct = currentRisk > newRisk
    ? Math.min(65, Math.round(((currentRisk - newRisk) / currentRisk) * 100))
    : 0;

  // Estimated timeframe: 1kg fat ~= 7700 kcal. 400 kcal deficit/day ~= 1.5kg / month
  const estimatedWeeks = Math.max(2, Math.round(Math.abs(weightDeltaKg) * 2.5));

  const displayWaistDelta = isImperial
    ? `${Math.round(cmToInches(waistDeltaCm) * 10) / 10} in`
    : `${waistDeltaCm} cm`;

  const displayWeightDelta = isImperial
    ? `${Math.round(kgToLbs(weightDeltaKg) * 10) / 10} lbs`
    : `${weightDeltaKg} kg`;

  const handleReset = () => {
    setWaistDeltaCm(initialWaistDelta);
    setWeightDeltaKg(Math.round(initialWaistDelta * 0.7 * 10) / 10);
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 rounded-3xl p-5 sm:p-6 shadow-xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white tracking-wide">
                {t.whatIfTitle}
              </h3>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Future Simulation
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {t.whatIfDesc}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 self-start sm:self-auto transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{isUrdu ? 'ری سیٹ کریں' : 'Reset Target'}</span>
        </button>
      </div>

      {/* Interactive Sliders for What-If Changes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Waist reduction slider */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300" htmlFor="sim-waist">
              {t.simulatedWaistChange}
            </label>
            <span className="text-sm font-mono font-bold text-emerald-400">
              -{displayWaistDelta}
            </span>
          </div>
          <input
            id="sim-waist"
            type="range"
            min={0}
            max={isImperial ? 8 : 20}
            step={0.5}
            value={isImperial ? Math.round(cmToInches(waistDeltaCm) * 10) / 10 : waistDeltaCm}
            onChange={(e) => {
              const val = Number(e.target.value);
              const cm = isImperial ? val * 2.54 : val;
              setWaistDeltaCm(Math.round(cm * 10) / 10);
            }}
            className="w-full accent-emerald-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>0</span>
            <span>
              {isUrdu ? 'ہدف: ' : 'Target Waist: '}
              {isImperial ? `${Math.round(cmToInches(simulatedWaistCm) * 10) / 10} in` : `${simulatedWaistCm} cm`}
            </span>
            <span>{isImperial ? '8 in' : '20 cm'}</span>
          </div>
        </div>

        {/* Weight change slider */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300" htmlFor="sim-weight">
              {t.simulatedWeightChange}
            </label>
            <span className="text-sm font-mono font-bold text-cyan-400">
              -{displayWeightDelta}
            </span>
          </div>
          <input
            id="sim-weight"
            type="range"
            min={0}
            max={isImperial ? 35 : 18}
            step={0.5}
            value={isImperial ? Math.round(kgToLbs(weightDeltaKg) * 10) / 10 : weightDeltaKg}
            onChange={(e) => {
              const val = Number(e.target.value);
              const kg = isImperial ? val / 2.20462 : val;
              setWeightDeltaKg(Math.round(kg * 10) / 10);
            }}
            className="w-full accent-cyan-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>0</span>
            <span>
              {isUrdu ? 'ہدف: ' : 'Target Weight: '}
              {isImperial ? `${Math.round(kgToLbs(simulatedWeightKg) * 10) / 10} lbs` : `${simulatedWeightKg} kg`}
            </span>
            <span>{isImperial ? '35 lbs' : '18 kg'}</span>
          </div>
        </div>
      </div>

      {/* Simulated Transformation Matrix: Current vs Future */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/90 border border-slate-800 p-4 rounded-2xl">
        {/* Metric 1: WHtR */}
        <div className="text-center p-2 rounded-xl bg-slate-900 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
            Waist / Height
          </span>
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-xs text-slate-400 line-through font-mono">{currentResults.whtr}</span>
            <ArrowRight className="w-3 h-3 text-emerald-400" />
            <span className="text-base font-extrabold font-mono text-emerald-400">{simulatedResults.whtr}</span>
          </div>
          <span className="text-[10px] font-semibold text-emerald-400 block mt-1">
            {simulatedResults.whtr <= 0.49 ? '✓ Safe Zone' : 'Improved'}
          </span>
        </div>

        {/* Metric 2: Body Fat */}
        <div className="text-center p-2 rounded-xl bg-slate-900 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
            Body Fat %
          </span>
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-xs text-slate-400 line-through font-mono">{currentResults.bodyFatPercentage}%</span>
            <ArrowRight className="w-3 h-3 text-cyan-400" />
            <span className="text-base font-extrabold font-mono text-cyan-400">{simulatedResults.bodyFatPercentage}%</span>
          </div>
          <span className="text-[10px] font-semibold text-cyan-400 block mt-1">
            {simulatedResults.bodyFatCategoryLabel}
          </span>
        </div>

        {/* Metric 3: BMI */}
        <div className="text-center p-2 rounded-xl bg-slate-900 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
            BMI
          </span>
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-xs text-slate-400 line-through font-mono">{currentResults.bmi}</span>
            <ArrowRight className="w-3 h-3 text-blue-400" />
            <span className="text-base font-extrabold font-mono text-blue-400">{simulatedResults.bmi}</span>
          </div>
          <span className="text-[10px] font-semibold text-blue-400 block mt-1">
            {simulatedResults.bmiCategoryLabel}
          </span>
        </div>

        {/* Metric 4: Visceral Fat */}
        <div className="text-center p-2 rounded-xl bg-slate-900 border border-slate-800/80">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold mb-1">
            Visceral Fat Level
          </span>
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-xs text-slate-400 line-through font-mono">L{currentResults.visceralFatIndex}</span>
            <ArrowRight className="w-3 h-3 text-amber-400" />
            <span className="text-base font-extrabold font-mono text-amber-400">L{simulatedResults.visceralFatIndex}</span>
          </div>
          <span className="text-[10px] font-semibold text-amber-400 block mt-1">
            {simulatedResults.visceralFatStatus}
          </span>
        </div>
      </div>

      {/* High-Impact Benefit Banner */}
      <div className="bg-emerald-950/50 border border-emerald-500/40 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                {isUrdu ? 'متوقع طبی فائدہ:' : 'Clinical Outcome Projection:'}
              </span>
              {riskReducedPct > 0 && (
                <span className="text-xs font-black px-2 py-0.5 rounded bg-emerald-500 text-slate-950">
                  -{riskReducedPct}% CVD Risk
                </span>
              )}
            </div>
            <p className="text-xs text-slate-200 mt-0.5">
              {isUrdu
                ? `اس ہدف پر پہنچنے سے آپ کا میٹابولک اسکور ${simulatedResults.metabolicScore}/100 ہو جائے گا (تخمینہ: تقریباً ${estimatedWeeks} ہفتے معتدل روٹین کے ساتھ)۔`
                : `Achieving this simulation elevates your Metabolic Vitality Score to ${simulatedResults.metabolicScore}/100 (~${estimatedWeeks} weeks sustainable protocol).`}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onApplyGoal({ waistCm: simulatedWaistCm, weightKg: simulatedWeightKg })}
          className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 shrink-0 active:scale-95"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isUrdu ? 'اسے موجودہ ہدف بنائیں' : 'Commit As Target Goal'}</span>
        </button>
      </div>
    </div>
  );
};
