/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Activity, Globe, Scale, History, Printer } from 'lucide-react';
import { UnitSystem, StandardType } from '../utils/healthCalculations';
import { Language } from '../types';
import { getTranslation } from '../utils/translations';

interface HeaderProps {
  unitSystem: UnitSystem;
  onUnitSystemChange: (units: UnitSystem) => void;
  standard: StandardType;
  onStandardChange: (std: StandardType) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenHistory: () => void;
  onOpenExport: () => void;
  savedScansCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  unitSystem,
  onUnitSystemChange,
  standard,
  onStandardChange,
  language,
  onLanguageChange,
  onOpenHistory,
  onOpenExport,
  savedScansCount,
}) => {
  const t = getTranslation(language);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-xl backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Logo & Clinical Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black">
              <Activity className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                  {t.appTitle}
                </h1>
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Tri-Metric Matrix
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Quick Settings & Navigation Bar */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Units Toggle */}
            <div className="flex items-center bg-slate-800/90 p-1 rounded-lg border border-slate-700 text-xs">
              <button
                type="button"
                onClick={() => onUnitSystemChange('metric')}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  unitSystem === 'metric'
                    ? 'bg-emerald-500 text-slate-950 shadow font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
                aria-label="Switch to Metric units"
              >
                cm / kg
              </button>
              <button
                type="button"
                onClick={() => onUnitSystemChange('imperial')}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  unitSystem === 'imperial'
                    ? 'bg-emerald-500 text-slate-950 shadow font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
                aria-label="Switch to Imperial units"
              >
                in / lbs
              </button>
            </div>

            {/* WHO Standard Toggle */}
            <button
              type="button"
              onClick={() => onStandardChange(standard === 'who' ? 'asian' : 'who')}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs transition-colors ${
                standard === 'asian'
                  ? 'bg-cyan-950/70 border-cyan-500/60 text-cyan-300 font-medium'
                  : 'bg-slate-800/90 border-slate-700 text-slate-300 hover:border-slate-600'
              }`}
              title="WHO South Asian cutoffs identify overweight at BMI ≥ 23 and obesity at ≥ 27.5 due to higher central fat"
              aria-label="Toggle WHO Assessment Standard"
            >
              <Scale className="w-3.5 h-3.5 text-cyan-400" />
              <span>{standard === 'asian' ? 'Asian Cutoff (23+)' : 'WHO Standard'}</span>
            </button>

            {/* Language Toggle */}
            <button
              type="button"
              onClick={() => onLanguageChange(language === 'en' ? 'ur' : 'en')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700 hover:border-slate-600 text-xs text-slate-300 font-medium transition-colors"
              aria-label="Switch language between English and Urdu"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'en' ? 'اردو' : 'English'}</span>
            </button>

            {/* History Action */}
            <button
              type="button"
              onClick={onOpenHistory}
              className="relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700 hover:border-slate-600 text-xs text-slate-200 transition-colors"
              aria-label="Open scan history and logs"
            >
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{language === 'ur' ? 'ہسٹری' : 'History'}</span>
              {savedScansCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center">
                  {savedScansCount}
                </span>
              )}
            </button>

            {/* Export / Print */}
            <button
              type="button"
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition-colors"
              aria-label="Export or print clinical metabolic report"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'ur' ? 'رپورٹ' : 'Report'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
