/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Trash2, Printer, Calendar, ArrowRight, ShieldCheck, Download, History } from 'lucide-react';
import { SavedScanRecord, Language } from '../types';
import { HealthAnalysisResult, UnitSystem, cmToInches, kgToLbs } from '../utils/healthCalculations';

interface HistoryAndExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedScans: SavedScanRecord[];
  onDeleteScan: (id: string) => void;
  onClearHistory: () => void;
  currentResults: HealthAnalysisResult;
  currentUnitSystem: UnitSystem;
  language: Language;
}

export const HistoryAndExportModal: React.FC<HistoryAndExportModalProps> = ({
  isOpen,
  onClose,
  savedScans,
  onDeleteScan,
  onClearHistory,
  currentResults,
  currentUnitSystem,
  language,
}) => {
  const [activeView, setActiveView] = useState<'history' | 'report'>('history');
  const [selectedScanForCompare, setSelectedScanForCompare] = useState<string | null>(null);

  if (!isOpen) return null;

  const isUrdu = language === 'ur';
  const isImperial = currentUnitSystem === 'imperial';

  const comparedScan = savedScans.find((s) => s.id === selectedScanForCompare);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-emerald-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {isUrdu ? 'ہسٹری لاگ اور میڈیکل رپورٹ' : 'Metabolic Log & Clinical Summary'}
              </h2>
              <p className="text-xs text-slate-400">
                {isUrdu ? 'محفوظ کردہ اسکینز اور موازنہ' : 'Track longitudinal biometric evolution'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setActiveView('history')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  activeView === 'history' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400'
                }`}
              >
                {isUrdu ? 'ہسٹری' : 'History'}
              </button>
              <button
                type="button"
                onClick={() => setActiveView('report')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  activeView === 'report' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400'
                }`}
              >
                {isUrdu ? 'پرنٹ ایبل رپورٹ' : 'Clinical Report'}
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {activeView === 'history' ? (
            <div className="space-y-4">
              {savedScans.length === 0 ? (
                <div className="text-center py-12 text-slate-400 space-y-2">
                  <p className="text-sm font-semibold">
                    {isUrdu ? 'کوئی محفوظ اسکین موجود نہیں' : 'No saved biometric scans found.'}
                  </p>
                  <p className="text-xs text-slate-500">
                    {isUrdu
                      ? 'مین اسکرین پر "اسکین محفوظ کریں" کا بٹن دبا کر ریکارڈ محفوظ کریں۔'
                      : 'Click "Save Scan to History" on the main dashboard to store your baseline.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400 pb-1">
                    <span>
                      {isUrdu ? `کل محفوظ اسکینز: ${savedScans.length}` : `Saved Records (${savedScans.length})`}
                    </span>
                    <button
                      type="button"
                      onClick={onClearHistory}
                      className="text-rose-400 hover:text-rose-300 font-medium"
                    >
                      {isUrdu ? 'تمام حذف کریں' : 'Clear All'}
                    </button>
                  </div>

                  {savedScans.map((scan) => (
                    <div
                      key={scan.id}
                      className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-white">{scan.label}</span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {new Date(scan.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 font-mono">
                          <span>BMI: <strong className="text-blue-400">{scan.results.bmi}</strong></span>
                          <span>Fat: <strong className="text-emerald-400">{scan.results.bodyFatPercentage}%</strong></span>
                          <span>WHtR: <strong className="text-cyan-400">{scan.results.whtr}</strong></span>
                          <span>Waist: <strong>{scan.inputs.waistCm}cm</strong></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            setSelectedScanForCompare(
                              selectedScanForCompare === scan.id ? null : scan.id
                            )
                          }
                          className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                            selectedScanForCompare === scan.id
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                              : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                          }`}
                        >
                          {selectedScanForCompare === scan.id ? 'Comparing' : 'Compare'}
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteScan(scan.id)}
                          className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900 transition-colors"
                          title="Delete record"
                          aria-label="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Comparison Tray if a scan is selected */}
                  {comparedScan && (
                    <div className="mt-4 p-4 rounded-2xl bg-slate-900 border-2 border-emerald-500/50 space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-emerald-400 uppercase tracking-wider">
                          Comparison: Past vs Current
                        </span>
                        <span className="text-slate-400 text-[10px]">
                          {new Date(comparedScan.timestamp).toLocaleDateString()} vs Today
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="p-2 rounded-xl bg-slate-950">
                          <span className="text-[10px] text-slate-400 block">Waist Change</span>
                          <span className="font-mono font-bold text-sm">
                            {comparedScan.inputs.waistCm}cm → {currentResults.targetWaistCm}cm
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-950">
                          <span className="text-[10px] text-slate-400 block">Body Fat Delta</span>
                          <span className="font-mono font-bold text-sm">
                            {comparedScan.results.bodyFatPercentage}% → {currentResults.bodyFatPercentage}%
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-950">
                          <span className="text-[10px] text-slate-400 block">WHtR Delta</span>
                          <span className="font-mono font-bold text-sm">
                            {comparedScan.results.whtr} → {currentResults.whtr}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            /* Printable Report View */
            <div id="printable-health-report" className="space-y-4 bg-white text-slate-900 p-6 rounded-2xl shadow-inner font-sans">
              <div className="border-b-2 border-slate-900 pb-4 flex justify-between items-start">
                <div>
                  <h1 className="text-xl font-black tracking-tight text-slate-900">
                    METAPULSE CLINICAL HEALTH MATRIX
                  </h1>
                  <p className="text-xs text-slate-600">
                    Comprehensive Body Composition, Visceral Adipose & Waist-to-Height Diagnostic
                  </p>
                </div>
                <div className="text-right text-xs text-slate-500">
                  <div>Date: {new Date().toLocaleDateString()}</div>
                  <div className="font-mono text-[10px]">Doc ID: MP-{Date.now().toString().slice(-6)}</div>
                </div>
              </div>

              {/* Core Triad Table */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border border-slate-300 bg-slate-50 text-center">
                  <div className="text-[10px] uppercase font-bold text-slate-500">Body Mass Index (BMI)</div>
                  <div className="text-2xl font-black font-mono mt-0.5">{currentResults.bmi}</div>
                  <div className="text-[11px] font-semibold text-slate-700">{currentResults.bmiCategoryLabel}</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-300 bg-slate-50 text-center">
                  <div className="text-[10px] uppercase font-bold text-slate-500">US Navy Body Fat %</div>
                  <div className="text-2xl font-black font-mono mt-0.5 text-emerald-700">{currentResults.bodyFatPercentage}%</div>
                  <div className="text-[11px] font-semibold text-slate-700">{currentResults.bodyFatCategoryLabel}</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-300 bg-slate-50 text-center">
                  <div className="text-[10px] uppercase font-bold text-slate-500">Waist-to-Height (WHtR)</div>
                  <div className="text-2xl font-black font-mono mt-0.5 text-blue-700">{currentResults.whtr}</div>
                  <div className="text-[11px] font-semibold text-slate-700">{currentResults.whtrCategoryLabel}</div>
                </div>
              </div>

              {/* Diagnosis */}
              <div className="p-3.5 rounded-lg border border-slate-300 bg-slate-50 space-y-1">
                <div className="text-xs font-bold text-slate-900 uppercase">
                  Phenotypic Diagnosis: {currentResults.phenotypeTitle}
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {currentResults.phenotypeDescription}
                </p>
              </div>

              {/* Targets */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg border border-slate-300">
                  <div className="font-bold text-slate-900 mb-1">Waist Circumference Target</div>
                  <div>Current: <strong className="font-mono">{currentResults.targetWaistCm + currentResults.waistExcessCm} cm</strong></div>
                  <div>Safe Target: <strong className="font-mono text-emerald-700">{currentResults.targetWaistCm} cm</strong></div>
                  <div>Excess: <strong className="font-mono text-rose-700">{currentResults.waistExcessCm} cm</strong></div>
                </div>
                <div className="p-3 rounded-lg border border-slate-300">
                  <div className="font-bold text-slate-900 mb-1">Metabolic Baseline & Daily Energy</div>
                  <div>BMR: <strong className="font-mono">{currentResults.bmr} kcal</strong></div>
                  <div>Maintenance (TDEE): <strong className="font-mono">{currentResults.tdee} kcal</strong></div>
                  <div>Fat Loss Deficit: <strong className="font-mono text-blue-700">{currentResults.calorieTargets.standardLoss} kcal</strong></div>
                </div>
              </div>

              <div className="pt-2 text-[10px] text-slate-500 border-t border-slate-200 flex justify-between items-center">
                <span>Calculated via US Navy Formula, Mifflin-St Jeor & Dr. Margaret Ashwell WHtR protocol.</span>
                <span>Confidential Biometric Record</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            {isUrdu ? 'ڈیٹا مکمل طور پر آپ کی ڈیوائس پر محفوظ ہے' : 'Data is stored locally on this device.'}
          </span>
          <div className="flex items-center gap-2">
            {activeView === 'report' && (
              <button
                type="button"
                onClick={handlePrint}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all shadow-lg"
              >
                <Printer className="w-4 h-4" />
                <span>{isUrdu ? 'پرنٹ / پی ڈی ایف محفوظ کریں' : 'Print / Save PDF'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
            >
              {isUrdu ? 'بند کریں' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
