/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Eye, Shield, Activity, Sparkles, Layers } from 'lucide-react';
import { HealthAnalysisResult, UserBodyInputs } from '../utils/healthCalculations';
import { Language } from '../types';

interface BodySilhouetteVisualizerProps {
  inputs: UserBodyInputs;
  results: HealthAnalysisResult;
  language: Language;
}

export const BodySilhouetteVisualizer: React.FC<BodySilhouetteVisualizerProps> = ({
  inputs,
  results,
  language,
}) => {
  const [showTargetOverlay, setShowTargetOverlay] = useState(true);
  const [showVisceralLayer, setShowVisceralLayer] = useState(true);
  const [hoveredZone, setHoveredZone] = useState<string | null>(null);

  const isUrdu = language === 'ur';
  const isFemale = inputs.gender === 'female';

  // Normalize proportions for SVG rendering (viewBox: 0 0 300 480)
  // Base waist width in pixels: standard waist ~ 80cm -> width ~ 60px
  // Let waist width scale from 48px to 110px
  const waistCm = inputs.waistCm;
  const targetWaistCm = results.targetWaistCm;

  const currentWaistRadiusX = Math.max(24, Math.min(62, (waistCm / 80) * 38));
  const targetWaistRadiusX = Math.max(24, Math.min(62, (targetWaistCm / 80) * 38));

  // Chest & Shoulder width
  const shoulderRadiusX = isFemale ? 54 : 66;
  const hipRadiusX = isFemale
    ? Math.max(38, Math.min(68, (inputs.hipCm / 95) * 48))
    : Math.max(32, Math.min(58, (inputs.hipCm / 95) * 40));

  // Visceral fat intensity color (scale 1 - 25)
  const vfi = results.visceralFatIndex;
  const visceralColor =
    vfi <= 9 ? 'rgba(52, 211, 153, 0.45)' : vfi <= 14 ? 'rgba(251, 191, 36, 0.65)' : 'rgba(244, 63, 94, 0.85)';

  // Silhouette path builder
  // Head: center at (150, 48), radius 22
  // Neck: (140, 70) to (160, 70)
  // Left shoulder: (150 - shoulderRadiusX, 100)
  // Left chest: (150 - shoulderRadiusX + 6, 140)
  // Left waist: (150 - currentWaistRadiusX, 210)
  // Left hip: (150 - hipRadiusX, 270)
  // Crotch: (150, 310)
  // Left leg: down to (115, 450)
  // Right leg: down to (185, 450)
  // Right hip: (150 + hipRadiusX, 270)
  // Right waist: (150 + currentWaistRadiusX, 210)
  // Right chest: (150 + shoulderRadiusX - 6, 140)
  // Right shoulder: (150 + shoulderRadiusX, 100)

  const leftShoulderX = 150 - shoulderRadiusX;
  const rightShoulderX = 150 + shoulderRadiusX;
  const leftWaistX = 150 - currentWaistRadiusX;
  const rightWaistX = 150 + currentWaistRadiusX;
  const leftTargetWaistX = 150 - targetWaistRadiusX;
  const rightTargetWaistX = 150 + targetWaistRadiusX;
  const leftHipX = 150 - hipRadiusX;
  const rightHipX = 150 + hipRadiusX;

  const currentBodyPath = `
    M 142,70
    C 130,80 ${leftShoulderX + 8},92 ${leftShoulderX},105
    C ${leftShoulderX - 2},125 ${leftShoulderX + 4},145 ${leftShoulderX + 6},155
    C ${leftShoulderX + 4},175 ${leftWaistX - 4},190 ${leftWaistX},215
    C ${leftWaistX - 2},235 ${leftHipX - 4},250 ${leftHipX},275
    C ${leftHipX + 4},305 136,312 142,320
    L 128,450
    L 142,450
    L 149,340
    L 151,340
    L 158,450
    L 172,450
    L 158,320
    C 164,312 ${rightHipX - 4},305 ${rightHipX},275
    C ${rightHipX + 4},250 ${rightWaistX + 2},235 ${rightWaistX},215
    C ${rightWaistX + 4},190 ${rightShoulderX - 4},175 ${rightShoulderX - 6},155
    C ${rightShoulderX - 4},145 ${rightShoulderX + 2},125 ${rightShoulderX},105
    C ${rightShoulderX - 8},92 170,80 158,70
    Z
  `;

  const targetBodyPath = `
    M 142,70
    C 130,80 ${leftShoulderX + 8},92 ${leftShoulderX},105
    C ${leftShoulderX - 2},125 ${leftShoulderX + 4},145 ${leftShoulderX + 6},155
    C ${leftShoulderX + 4},175 ${leftTargetWaistX - 4},190 ${leftTargetWaistX},215
    C ${leftTargetWaistX - 2},235 ${leftHipX - 4},250 ${leftHipX},275
    C ${leftHipX + 4},305 136,312 142,320
    L 128,450
    L 142,450
    L 149,340
    L 151,340
    L 158,450
    L 172,450
    L 158,320
    C 164,312 ${rightHipX - 4},305 ${rightHipX},275
    C ${rightHipX + 4},250 ${rightTargetWaistX + 2},235 ${rightTargetWaistX},215
    C ${rightTargetWaistX + 4},190 ${rightShoulderX - 4},175 ${rightShoulderX - 6},155
    C ${rightShoulderX - 4},145 ${rightShoulderX + 2},125 ${rightShoulderX},105
    C ${rightShoulderX - 8},92 170,80 158,70
    Z
  `;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col justify-between">
      {/* Header and Controls */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white tracking-wide">
              {isUrdu ? 'ریئل ٹائم باڈی مارف اور وسرل فیٹ ماڈل' : 'Dynamic Silhouette & Visceral Fat Cross-Section'}
            </h3>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
            {isFemale ? 'Female Model' : 'Male Model'}
          </span>
        </div>
        <p className="text-xs text-slate-400 mb-4">
          {isUrdu
            ? 'جیسے جیسے آپ سلائیڈرز ہلائیں گے، جسم کی شکل اور اندرونی چربی ریئل ٹائم میں تبدیل ہوگی۔'
            : 'Interactive visual biomechanics: adjusts dynamically to waist, height, and visceral fat index.'}
        </p>

        {/* Layer Toggles */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <button
            type="button"
            onClick={() => setShowVisceralLayer(!showVisceralLayer)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
              showVisceralLayer
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'اندرونی چربی (Visceral Fat)' : 'Visceral Adipose Layer'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowTargetOverlay(!showTargetOverlay)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
              showTargetOverlay
                ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{isUrdu ? 'محفوظ ہدف خاکہ (Target Outline)' : 'Target Heart-Safe Frame'}</span>
          </button>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative bg-slate-950 rounded-2xl border border-slate-800/80 p-3 flex items-center justify-center overflow-hidden min-h-[380px]">
        {/* Subtle grid background */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: 'radial-gradient(#34d399 1px, transparent 1px)',
            backgroundSize: '16px 16px',
          }}
        />

        <svg
          viewBox="0 0 300 480"
          className="w-full max-w-[280px] h-[370px] drop-shadow-2xl transition-all duration-300"
          aria-label="Dynamic body silhouette and visceral fat model"
        >
          <defs>
            {/* Visceral Fat Radial Glow */}
            <radialGradient id="visceralGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={visceralColor} stopOpacity="0.9" />
              <stop offset="60%" stopColor={visceralColor} stopOpacity="0.4" />
              <stop offset="100%" stopColor={visceralColor} stopOpacity="0.0" />
            </radialGradient>

            {/* Body gradient */}
            <linearGradient id="bodySkinGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="50%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#020617" />
            </linearGradient>

            {/* Target outline stroke */}
            <linearGradient id="targetOutline" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>
          </defs>

          {/* Target Safe Silhouette Overlay (Ghost Outline) */}
          {showTargetOverlay && results.waistExcessCm > 0 && (
            <g opacity="0.6">
              <path
                d={targetBodyPath}
                fill="none"
                stroke="url(#targetOutline)"
                strokeWidth="1.5"
                strokeDasharray="4 3"
                className="transition-all duration-300"
              />
              {/* Target waist indicator line */}
              <line
                x1={leftTargetWaistX}
                y1="215"
                x2={rightTargetWaistX}
                y2="215"
                stroke="#10b981"
                strokeWidth="1.5"
                strokeDasharray="2 2"
              />
              <text
                x="150"
                y="200"
                fill="#34d399"
                fontSize="9"
                textAnchor="middle"
                fontFamily="monospace"
                fontWeight="bold"
              >
                Safe Target: {results.targetWaistCm}cm
              </text>
            </g>
          )}

          {/* Current Body Silhouette */}
          <g>
            {/* Head */}
            <circle
              cx="150"
              cy="46"
              r="22"
              fill="url(#bodySkinGradient)"
              stroke="#475569"
              strokeWidth="1.5"
            />

            {/* Body Main Mesh */}
            <path
              d={currentBodyPath}
              fill="url(#bodySkinGradient)"
              stroke="#38bdf8"
              strokeWidth="2"
              className="transition-all duration-300"
            />
          </g>

          {/* Internal Organs & Visceral Fat Cross-Section */}
          {showVisceralLayer && (
            <g
              className="cursor-pointer transition-all duration-300"
              onMouseEnter={() => setHoveredZone('visceral')}
              onMouseLeave={() => setHoveredZone(null)}
            >
              {/* Internal Visceral Adipose Cloud surrounding abdominal organs */}
              <ellipse
                cx="150"
                cy="215"
                rx={Math.max(16, currentWaistRadiusX * 0.75)}
                ry={Math.max(22, (vfi / 15) * 32)}
                fill="url(#visceralGlow)"
                className="animate-pulse"
              />

              {/* Core Liver & Mesenteric center */}
              <circle
                cx="145"
                cy="195"
                r="10"
                fill="#f43f5e"
                opacity="0.35"
                stroke="#fda4af"
                strokeWidth="0.8"
              />
              <circle
                cx="158"
                cy="210"
                r="8"
                fill="#f59e0b"
                opacity="0.35"
                stroke="#fcd34d"
                strokeWidth="0.8"
              />

              {/* Waist measurement calipers */}
              <line
                x1={leftWaistX}
                y1="215"
                x2={rightWaistX}
                y2="215"
                stroke={results.whtr > 0.49 ? '#f43f5e' : '#34d399'}
                strokeWidth="2"
              />
              <circle cx={leftWaistX} cy="215" r="3" fill="#f43f5e" />
              <circle cx={rightWaistX} cy="215" r="3" fill="#f43f5e" />
            </g>
          )}

          {/* Chest Heart Beat Icon */}
          <g transform="translate(142, 140)">
            <circle cx="8" cy="8" r="8" fill="#e11d48" opacity="0.8" className="animate-ping" />
            <circle cx="8" cy="8" r="6" fill="#f43f5e" />
          </g>
        </svg>

        {/* Hovered Tooltip */}
        {hoveredZone === 'visceral' && (
          <div className="absolute bottom-3 left-3 right-3 bg-slate-900/95 border border-amber-500/60 p-2.5 rounded-xl text-xs text-slate-200 shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between font-bold text-amber-400 mb-1">
              <span>{isUrdu ? 'وسرل فیٹ کی تفصیل:' : 'Deep Visceral Adipose Cross-Section:'}</span>
              <span className="font-mono">VFI: {results.visceralFatIndex}/25</span>
            </div>
            <p className="text-[11px] text-slate-300">
              {isUrdu
                ? 'یہ چربی جلد کے نیچے نہیں بلکہ جگر اور دل کے گرد جمع ہوتی ہے جو انسولین ریزسٹنس کا سبب بنتی ہے۔'
                : 'Deep visceral fat envelops liver, pancreas, and intestines. Unlike subcutaneous fat, it actively secretes inflammatory cytokines.'}
            </p>
          </div>
        )}
      </div>

      {/* Visceral Fat Index Score Bar below Silhouette */}
      <div className="mt-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-amber-400" />
          <div>
            <span className="font-bold text-white block">
              {isUrdu ? 'وسرل فیٹ انڈیکس (VFI):' : 'Visceral Fat Index (VFI):'}
            </span>
            <span className="text-[11px] text-slate-400">
              {results.visceralFatStatus === 'healthy'
                ? (isUrdu ? 'صحت مند محفوظ رینج (1-9)' : 'Optimal Safe Zone (1 - 9)')
                : results.visceralFatStatus === 'elevated'
                ? (isUrdu ? 'معتدل اضافہ (10-14)' : 'Elevated Cushion (10 - 14)')
                : (isUrdu ? 'زیادہ خطرہ (15+)' : 'Critical Visceral Load (15+)')}
            </span>
          </div>
        </div>
        <div className="text-right">
          <span className={`text-base font-black font-mono px-2.5 py-1 rounded-lg border ${
            vfi <= 9
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              : vfi <= 14
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-rose-500/20 text-rose-400 border-rose-500/40'
          }`}>
            Level {results.visceralFatIndex}
          </span>
        </div>
      </div>
    </div>
  );
};
