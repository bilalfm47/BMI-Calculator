/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Gender = 'male' | 'female';
export type UnitSystem = 'metric' | 'imperial';
export type StandardType = 'who' | 'asian';

export type ActivityLevel =
  | 'sedentary'
  | 'light'
  | 'moderate'
  | 'active'
  | 'very_active';

export interface UserBodyInputs {
  gender: Gender;
  age: number; // years
  unitSystem: UnitSystem;
  heightCm: number;
  weightKg: number;
  waistCm: number;
  neckCm: number;
  hipCm: number; // Primarily for females
  activityLevel: ActivityLevel;
  standard: StandardType;
}

export type BMICategory =
  | 'severely_underweight'
  | 'underweight'
  | 'normal'
  | 'overweight'
  | 'obese_class_1'
  | 'obese_class_2'
  | 'obese_class_3';

export type WHtRCategory =
  | 'take_care_slim'
  | 'healthy'
  | 'increased_risk'
  | 'high_risk';

export type BodyFatCategory =
  | 'essential_fat'
  | 'athletes'
  | 'fitness'
  | 'average'
  | 'obese';

export type PhenotypeType =
  | 'optimal'
  | 'athletic_paradox'
  | 'normal_weight_obesity' // "Skinny Fat"
  | 'central_adiposity'
  | 'high_metabolic_risk'
  | 'underweight_depletion';

export interface HealthAnalysisResult {
  bmi: number;
  bmiCategory: BMICategory;
  bmiCategoryLabel: string;
  bmiHealthyRange: { min: number; max: number };

  whtr: number;
  whtrCategory: WHtRCategory;
  whtrCategoryLabel: string;
  whtrRiskLevel: 'low' | 'moderate' | 'high' | 'critical';
  targetWaistCm: number;
  waistExcessCm: number; // >0 means waist is above healthy 0.49 ratio

  bodyFatPercentage: number;
  bodyFatMethod: 'navy' | 'bmi_estimate';
  bodyFatCategory: BodyFatCategory;
  bodyFatCategoryLabel: string;

  fatMassKg: number;
  leanMassKg: number;

  visceralFatIndex: number; // Scale 1 - 25+
  visceralFatStatus: 'healthy' | 'elevated' | 'high' | 'very_high';

  bmr: number; // Basal Metabolic Rate kcal/day
  tdee: number; // Total Daily Energy Expenditure kcal/day
  calorieTargets: {
    mildLoss: number; // -300 kcal
    standardLoss: number; // -500 kcal
    maintenance: number;
    leanGain: number; // +250 kcal
  };

  phenotype: PhenotypeType;
  phenotypeTitle: string;
  phenotypeDescription: string;
  phenotypeUrduSummary: string;

  metabolicScore: number; // 0 - 100 overall composite metabolic health score
  cardiovascularRiskMultiplier: number; // Relative risk compared to optimal WHtR
}

// Unit conversion helpers
export const cmToInches = (cm: number): number => cm / 2.54;
export const inchesToCm = (inches: number): number => inches * 2.54;
export const kgToLbs = (kg: number): number => kg * 2.20462;
export const lbsToKg = (lbs: number): number => lbs / 2.20462;

export const ACTIVITY_MULTIPLIERS: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very_active: 1.9,
};

/**
 * Calculates BMI in kg/m^2
 */
export function calculateBMI(heightCm: number, weightKg: number): number {
  if (heightCm <= 0 || weightKg <= 0) return 0;
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);
  return Math.round(bmi * 10) / 10;
}

/**
 * Classifies BMI according to WHO Standard or WHO Asian / South Asian criteria
 */
export function getBMICategory(
  bmi: number,
  standard: StandardType = 'who'
): { category: BMICategory; label: string; healthyRange: { min: number; max: number } } {
  if (standard === 'asian') {
    // Asian WHO Cutoffs: <18.5 Underweight, 18.5-22.9 Normal, 23-27.4 Overweight, >=27.5 Obese
    const healthyRange = { min: 18.5, max: 22.9 };
    if (bmi < 16.5) return { category: 'severely_underweight', label: 'Severely Underweight (Asian)', healthyRange };
    if (bmi < 18.5) return { category: 'underweight', label: 'Underweight (Asian)', healthyRange };
    if (bmi <= 22.9) return { category: 'normal', label: 'Healthy Normal (Asian)', healthyRange };
    if (bmi <= 27.4) return { category: 'overweight', label: 'Overweight / At Risk (Asian)', healthyRange };
    if (bmi <= 32.4) return { category: 'obese_class_1', label: 'Obese Class I (Asian)', healthyRange };
    if (bmi <= 37.4) return { category: 'obese_class_2', label: 'Obese Class II (Asian)', healthyRange };
    return { category: 'obese_class_3', label: 'Obese Class III (Asian)', healthyRange };
  }

  // Standard WHO Cutoffs
  const healthyRange = { min: 18.5, max: 24.9 };
  if (bmi < 16.0) return { category: 'severely_underweight', label: 'Severely Underweight', healthyRange };
  if (bmi < 18.5) return { category: 'underweight', label: 'Underweight', healthyRange };
  if (bmi <= 24.9) return { category: 'normal', label: 'Healthy Normal', healthyRange };
  if (bmi <= 29.9) return { category: 'overweight', label: 'Overweight', healthyRange };
  if (bmi <= 34.9) return { category: 'obese_class_1', label: 'Obese Class I', healthyRange };
  if (bmi <= 39.9) return { category: 'obese_class_2', label: 'Obese Class II', healthyRange };
  return { category: 'obese_class_3', label: 'Obese Class III', healthyRange };
}

/**
 * Calculates Waist-to-Height Ratio (WHtR)
 * Formula: Waist / Height
 */
export function calculateWHtR(waistCm: number, heightCm: number): {
  whtr: number;
  category: WHtRCategory;
  categoryLabel: string;
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
  targetWaistCm: number;
  waistExcessCm: number;
} {
  if (heightCm <= 0 || waistCm <= 0) {
    return {
      whtr: 0,
      category: 'healthy',
      categoryLabel: 'N/A',
      riskLevel: 'low',
      targetWaistCm: 0,
      waistExcessCm: 0,
    };
  }

  const rawRatio = waistCm / heightCm;
  const whtr = Math.round(rawRatio * 100) / 100;
  // Maximum healthy waist is 0.49 * height
  const targetWaistCm = Math.round(heightCm * 0.49 * 10) / 10;
  const waistExcessCm = Math.max(0, Math.round((waistCm - targetWaistCm) * 10) / 10);

  let category: WHtRCategory = 'healthy';
  let categoryLabel = 'Healthy (Half-Height Rule Passed)';
  let riskLevel: 'low' | 'moderate' | 'high' | 'critical' = 'low';

  if (whtr < 0.4) {
    category = 'take_care_slim';
    categoryLabel = 'Underweight / Very Slim Waist (<0.40)';
    riskLevel = 'low';
  } else if (whtr <= 0.49) {
    category = 'healthy';
    categoryLabel = 'Optimal Heart Health Zone (0.40 - 0.49)';
    riskLevel = 'low';
  } else if (whtr <= 0.59) {
    category = 'increased_risk';
    categoryLabel = 'Increased Cardiometabolic Risk (0.50 - 0.59)';
    riskLevel = 'moderate';
  } else {
    category = 'high_risk';
    categoryLabel = 'Substantial / High Visceral Risk (≥0.60)';
    riskLevel = whtr >= 0.65 ? 'critical' : 'high';
  }

  return {
    whtr,
    category,
    categoryLabel,
    riskLevel,
    targetWaistCm,
    waistExcessCm,
  };
}

/**
 * Calculates Body Fat % using the US Navy Method (with Deurenberg fallback)
 */
export function calculateBodyFat(
  gender: Gender,
  age: number,
  heightCm: number,
  weightKg: number,
  waistCm: number,
  neckCm: number,
  hipCm: number
): {
  bodyFatPercentage: number;
  method: 'navy' | 'bmi_estimate';
  category: BodyFatCategory;
  categoryLabel: string;
} {
  const bmi = calculateBMI(heightCm, weightKg);
  let bf = 0;
  let method: 'navy' | 'bmi_estimate' = 'navy';

  // Check if US Navy inputs are valid
  const hasValidNavyInputs =
    gender === 'male'
      ? waistCm > neckCm && neckCm > 15 && heightCm > 50
      : waistCm + hipCm > neckCm && neckCm > 15 && hipCm > 30 && heightCm > 50;

  if (hasValidNavyInputs) {
    if (gender === 'male') {
      // Men: 495 / (1.0324 - 0.19077 * log10(waist - neck) + 0.15456 * log10(height)) - 450
      const waistMinusNeck = waistCm - neckCm;
      if (waistMinusNeck > 0) {
        const denom =
          1.0324 -
          0.19077 * Math.log10(waistMinusNeck) +
          0.15456 * Math.log10(heightCm);
        bf = 495 / denom - 450;
      }
    } else {
      // Women: 495 / (1.29579 - 0.35004 * log10(waist + hip - neck) + 0.22100 * log10(height)) - 450
      const waistHipMinusNeck = waistCm + hipCm - neckCm;
      if (waistHipMinusNeck > 0) {
        const denom =
          1.29579 -
          0.35004 * Math.log10(waistHipMinusNeck) +
          0.221 * Math.log10(heightCm);
        bf = 495 / denom - 450;
      }
    }
  }

  // Sanity check or fallback to Deurenberg formula
  if (isNaN(bf) || bf < 3 || bf > 65) {
    method = 'bmi_estimate';
    // Adult Deurenberg: (1.20 * BMI) + (0.23 * age) - (10.8 * sex) - 5.4 (sex: male=1, female=0)
    const sexVal = gender === 'male' ? 1 : 0;
    bf = 1.2 * bmi + 0.23 * age - 10.8 * sexVal - 5.4;
  }

  // Constrain to realistic human bounds
  bf = Math.max(3, Math.min(65, Math.round(bf * 10) / 10));

  // Determine category based on American Council on Exercise (ACE) standards
  let category: BodyFatCategory = 'average';
  let categoryLabel = 'Average';

  if (gender === 'male') {
    if (bf < 6) {
      category = 'essential_fat';
      categoryLabel = 'Essential Fat (2-5%)';
    } else if (bf <= 13.9) {
      category = 'athletes';
      categoryLabel = 'Athletes (6-13%)';
    } else if (bf <= 17.9) {
      category = 'fitness';
      categoryLabel = 'Fitness / Lean (14-17%)';
    } else if (bf <= 24.9) {
      category = 'average';
      categoryLabel = 'Average (18-24%)';
    } else {
      category = 'obese';
      categoryLabel = 'Overfat / Obese (≥25%)';
    }
  } else {
    if (bf < 14) {
      category = 'essential_fat';
      categoryLabel = 'Essential Fat (10-13%)';
    } else if (bf <= 20.9) {
      category = 'athletes';
      categoryLabel = 'Athletes (14-20%)';
    } else if (bf <= 24.9) {
      category = 'fitness';
      categoryLabel = 'Fitness / Lean (21-24%)';
    } else if (bf <= 31.9) {
      category = 'average';
      categoryLabel = 'Average (25-31%)';
    } else {
      category = 'obese';
      categoryLabel = 'Overfat / Obese (≥32%)';
    }
  }

  return {
    bodyFatPercentage: bf,
    method,
    category,
    categoryLabel,
  };
}

/**
 * Calculates Estimated Visceral Fat Index (Score 1 - 25)
 * Based on WHtR, age, and Body Fat %
 */
export function calculateVisceralFatIndex(
  whtr: number,
  bodyFatPercentage: number,
  age: number,
  gender: Gender
): {
  index: number;
  status: 'healthy' | 'elevated' | 'high' | 'very_high';
} {
  // Healthy baseline WHtR is around 0.44-0.47
  const whtrExcess = Math.max(0, whtr - 0.45);
  // Visceral fat accumulates deeper in men and with older age
  const genderWeight = gender === 'male' ? 1.2 : 0.95;
  const ageFactor = Math.max(0, (age - 20) * 0.08);

  const rawScore =
    4 +
    whtrExcess * 35 * genderWeight +
    (bodyFatPercentage / 10) * 1.3 +
    ageFactor;

  const index = Math.max(1, Math.min(25, Math.round(rawScore)));

  let status: 'healthy' | 'elevated' | 'high' | 'very_high' = 'healthy';
  if (index <= 9) {
    status = 'healthy';
  } else if (index <= 14) {
    status = 'elevated';
  } else if (index <= 19) {
    status = 'high';
  } else {
    status = 'very_high';
  }

  return { index, status };
}

/**
 * Basal Metabolic Rate (BMR) via Mifflin-St Jeor
 */
export function calculateBMR(
  gender: Gender,
  weightKg: number,
  heightCm: number,
  age: number
): number {
  if (weightKg <= 0 || heightCm <= 0 || age <= 0) return 0;
  // Men: 10 * weight + 6.25 * height - 5 * age + 5
  // Women: 10 * weight + 6.25 * height - 5 * age - 161
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  const bmr = gender === 'male' ? base + 5 : base - 161;
  return Math.round(Math.max(800, bmr));
}

/**
 * Identifies metabolic phenotype, including "Skinny Fat" (Normal Weight Obesity)
 * and Athletic Paradox (Heavy muscle falsely categorized as overweight).
 */
export function detectPhenotype(
  bmi: number,
  bmiCategory: BMICategory,
  bodyFatPercentage: number,
  bodyFatCategory: BodyFatCategory,
  whtr: number,
  gender: Gender
): {
  phenotype: PhenotypeType;
  title: string;
  description: string;
  urduSummary: string;
} {
  const isMale = gender === 'male';
  const isHighBf = isMale ? bodyFatPercentage >= 25 : bodyFatPercentage >= 32;
  const isAthleticBf = isMale ? bodyFatPercentage <= 15 : bodyFatPercentage <= 22;
  const isHighWaist = whtr >= 0.5;

  // 1. Athletic Paradox: High BMI, but low body fat and healthy waist
  if ((bmiCategory === 'overweight' || bmiCategory === 'obese_class_1') && isAthleticBf && whtr < 0.52) {
    return {
      phenotype: 'athletic_paradox',
      title: 'Athletic Muscle Paradox (False Overweight)',
      description:
        'Standard BMI classifies you as overweight due to high muscular density, but your Waist-to-Height Ratio and low Body Fat show superior cardiovascular conditioning and zero excess visceral fat.',
      urduSummary:
        'Aapka BMI zyada hai lekin ye motapa nahi balkay mazboot muscle mass hai. Waist-to-height ratio bilkul safe hai aur dil ko koi khatra nahi.',
    };
  }

  // 2. Normal Weight Obesity ("Skinny Fat" / TOFI: Thin Outside, Fat Inside)
  if (bmiCategory === 'normal' && (isHighBf || isHighWaist)) {
    return {
      phenotype: 'normal_weight_obesity',
      title: 'Normal-Weight Obesity ("Skinny-Fat" / Hidden Visceral Fat)',
      description:
        'Standard BMI looks "normal", but your elevated waist ratio and body fat indicate hidden visceral fat surrounding internal organs. This carries silent risks for insulin resistance and cardiovascular strain despite normal scale weight.',
      urduSummary:
        'Ahem Tanbeeh: Scale par wazan theek lagta hai (Normal BMI), lekin pait ke ird gird charbi (Waist ratio) zyada hai. Is ko "Skinny-Fat" kehtay hain jahan exercise aur protein ki ashad zaroorat hoti hai.',
    };
  }

  // 3. High Metabolic & Cardiometabolic Risk
  if (whtr >= 0.6 || bmiCategory === 'obese_class_2' || bmiCategory === 'obese_class_3') {
    return {
      phenotype: 'high_metabolic_risk',
      title: 'High Central & Cardiometabolic Risk',
      description:
        'Both your BMI and Waist-to-Height Ratio significantly exceed clinical thresholds. Deep visceral adipose tissue is exerting pressure on cardiac load, liver metabolism, and arterial stiffness.',
      urduSummary:
        'Khatray ka zone: Pait ki charbi aur wazan dono safe limit se kafi barh chukay hain. Dil, blood pressure aur sugar ke khatray ko kam karne ke liye fouri action plan zaroori hai.',
    };
  }

  // 4. Central Adiposity / Early Metabolic Warning
  if (isHighWaist || isHighBf || bmiCategory === 'overweight') {
    return {
      phenotype: 'central_adiposity',
      title: 'Elevated Central Adiposity (Warning Zone)',
      description:
        'Waist circumference is exceeding half of height. Focusing on abdominal circumference reduction will dramatically improve blood lipids and longevity far more than just scale weight.',
      urduSummary:
        'Ahtiyat zaroori hai: Aapki kamar ka size qad ke nisf (half height) se zyada hai. Pait ki charbi kam karne se metabolic health bohat jald behtar ho sakti hai.',
    };
  }

  // 5. Underweight Depletion
  if (bmiCategory === 'severely_underweight' || bmiCategory === 'underweight') {
    return {
      phenotype: 'underweight_depletion',
      title: 'Underweight & Nutrient Depletion Risk',
      description:
        'BMI and body fat stores are below optimal physiological ranges, risking lean muscle wasting, hormonal imbalance, and immune depletion.',
      urduSummary:
        'Wazan zaroorat se kam hai. Taqatwar ghiza aur strength training ke zariye lean muscle aur energy barhanay ki zaroorat hai.',
    };
  }

  // 6. Optimal
  return {
    phenotype: 'optimal',
    title: 'Optimal Metabolic & Vascular Health',
    description:
      'All 3 pillars align: Healthy BMI, optimal Waist-to-Height Ratio (<0.50), and balanced Body Fat percentage. Strong cardiovascular resilience and longevity baseline.',
    urduSummary:
      'Mubarak ho! Aapka BMI, body fat percentage aur kamar ka ratio teeno misali (optimal) hain. Dil aur sehat bilkul mehfooz aur fit zone me hain.',
  };
}

/**
 * Computes comprehensive Real-time Health Analysis
 */
export function analyzeHealth(inputs: UserBodyInputs): HealthAnalysisResult {
  const { gender, age, heightCm, weightKg, waistCm, neckCm, hipCm, activityLevel, standard } = inputs;

  const bmi = calculateBMI(heightCm, weightKg);
  const bmiCat = getBMICategory(bmi, standard);
  const whtrData = calculateWHtR(waistCm, heightCm);
  const bfData = calculateBodyFat(gender, age, heightCm, weightKg, waistCm, neckCm, hipCm);

  const fatMassKg = Math.round((weightKg * (bfData.bodyFatPercentage / 100)) * 10) / 10;
  const leanMassKg = Math.round((weightKg - fatMassKg) * 10) / 10;

  const vfiData = calculateVisceralFatIndex(whtrData.whtr, bfData.bodyFatPercentage, age, gender);

  const bmr = calculateBMR(gender, weightKg, heightCm, age);
  const activityMultiplier = ACTIVITY_MULTIPLIERS[activityLevel] || 1.2;
  const tdee = Math.round(bmr * activityMultiplier);

  const phenotypeData = detectPhenotype(
    bmi,
    bmiCat.category,
    bfData.bodyFatPercentage,
    bfData.category,
    whtrData.whtr,
    gender
  );

  // Calculate Cardiovascular Risk Multiplier (based on Ashwell & UK NICE WHtR risk progression)
  let riskMultiplier = 1.0;
  if (whtrData.whtr > 0.5) {
    // Every 0.05 increase above 0.5 adds ~35-50% elevated relative risk of cardiometabolic incidents
    const excess = (whtrData.whtr - 0.5) / 0.05;
    riskMultiplier = Math.round((1.0 + excess * 0.45) * 10) / 10;
  } else if (whtrData.whtr < 0.4) {
    riskMultiplier = 1.15; // slightly elevated risk from extreme leanness/frailty
  }

  // Composite Metabolic Health Score (0 - 100)
  // Penalizes high WHtR heavily (the strongest mortality predictor), plus high BF and extreme BMI
  let score = 100;
  if (whtrData.whtr > 0.49) {
    score -= (whtrData.whtr - 0.49) * 200;
  }
  if (bmi > 25) {
    score -= (bmi - 25) * 2.5;
  } else if (bmi < 18.5) {
    score -= (18.5 - bmi) * 4;
  }
  if (gender === 'male' && bfData.bodyFatPercentage > 24) {
    score -= (bfData.bodyFatPercentage - 24) * 1.5;
  } else if (gender === 'female' && bfData.bodyFatPercentage > 31) {
    score -= (bfData.bodyFatPercentage - 31) * 1.5;
  }
  score = Math.max(12, Math.min(100, Math.round(score)));

  return {
    bmi,
    bmiCategory: bmiCat.category,
    bmiCategoryLabel: bmiCat.label,
    bmiHealthyRange: bmiCat.healthyRange,

    whtr: whtrData.whtr,
    whtrCategory: whtrData.category,
    whtrCategoryLabel: whtrData.categoryLabel,
    whtrRiskLevel: whtrData.riskLevel,
    targetWaistCm: whtrData.targetWaistCm,
    waistExcessCm: whtrData.waistExcessCm,

    bodyFatPercentage: bfData.bodyFatPercentage,
    bodyFatMethod: bfData.method,
    bodyFatCategory: bfData.category,
    bodyFatCategoryLabel: bfData.categoryLabel,

    fatMassKg,
    leanMassKg,

    visceralFatIndex: vfiData.index,
    visceralFatStatus: vfiData.status,

    bmr,
    tdee,
    calorieTargets: {
      mildLoss: Math.max(1200, tdee - 300),
      standardLoss: Math.max(1200, tdee - 500),
      maintenance: tdee,
      leanGain: tdee + 250,
    },

    phenotype: phenotypeData.phenotype,
    phenotypeTitle: phenotypeData.title,
    phenotypeDescription: phenotypeData.description,
    phenotypeUrduSummary: phenotypeData.urduSummary,

    metabolicScore: score,
    cardiovascularRiskMultiplier: riskMultiplier,
  };
}
